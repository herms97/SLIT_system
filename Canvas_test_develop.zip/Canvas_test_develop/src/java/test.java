/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author herma
 */

import java.io.PrintWriter;
import java.sql.*; 
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class test {
    Connection conn; 
    Statement stmt;
    
    public void skrivNavn(PrintWriter out){
        
         String test = "select * from studentInfo";
         //out. println("The SQL query is: " + test);
         out.println("Klasseliste, IS-202:<br>");
         
 
         try {
             
                ResultSet rset = stmt.executeQuery(test);
 
                // Step 4: Process the ResultSet by scrolling the cursor forward via next().
                //  For each row, retrieve the contents of the cells with getXxx(columnName).
                //out.println("The records selected are:" +"<br>");
                int rowCount = 0;
                while(rset.next()) {   // Move the cursor to the next row, return false if no more row
                    String studentID = rset.getString("studentID");
                    String studentName  = rset.getString("studentName");
                    String studentSurname  = rset.getString("studentSurname");
                    out.println(studentID + ", " + studentName + ", " + studentSurname +"<br>");
                    ++rowCount;
                 }  // end while
                 out.println("<br>"+"Antall elever i klassen: " + rowCount);
         } // end catch     
         catch (SQLException ex) {
                out.println("Ikke hentet fra DB " + ex);
         }
        
   }
    
    public void skrivMeldinger(PrintWriter out){
        
        String Meldinger = "select studentName, studentSurname, MessageSubject, Message\n" +
                            "from studentinfo\n" +
                            "INNER JOIN Message\n" +
                            "ON studentinfo.studentID = Message.studentID\n" +
                            "ORDER BY studentSurname";
        
        out.println("<h1>Sendte meldinger:<br></h1>");
        out.println("<br>");
        
                 try {
             
                ResultSet rset = stmt.executeQuery(Meldinger);
 
                // Step 4: Process the ResultSet by scrolling the cursor forward via next().
                //  For each row, retrieve the contents of the cells with getXxx(columnName).
                //out.println("The records selected are:" +"<br>");
                while(rset.next()) {   // Move the cursor to the next row, return false if no more row
                    String studentName = rset.getString("studentName");
                    String studentSurname  = rset.getString("studentSurname");
                    String MessageSubject  = rset.getString("MessageSubject");
                    String Message = rset.getString("Message");
                    out.println(studentName + " " + studentSurname + ", " + "Emne: " +MessageSubject +": "+ Message +"<br>");
                    out.println("<br>");
                 }  // end while
         } // end catch     
         catch (SQLException ex) {
                out.println("Ikke hentet fra DB " + ex);
         }
    }
    
    public void xX(PrintWriter out) {
        try {
         // Step 1: Allocate a database 'Connection' object
         Context cont = new InitialContext();
         DataSource ds = (DataSource)cont.lookup("java:comp/env/jdbc/localhostDS");  
         //DataSource ds = (DataSource)cont.lookup("jdbc/LocalhostDS");
         conn =  ds.getConnection();
 
         // Step 2: Allocate a 'Statement' object in the Connection
         stmt = conn.createStatement();
        }
        catch (SQLException ex ) {
            out.println("Not connected to database " + ex);
        }
        catch (NamingException nex) {
            out.println("Not correct naming" + nex);
        }
            
            
    }
    }

